import pandas as pd
from sklearn.model_selection import train_test_split
import Proposed_PJSO_HDLTex.Proposed_HDLTEX


def Main(PRE, RECALL, F_M, d_s):
    data = pd.read_csv("...\Feature.csv", header=None)
    label = pd.read_csv("...\label.csv", header=None)

    if d_s == "50":
        s = int(len(data) * 50/100)
        data = data[:s]
        label = label[:s]
    elif d_s == "75":
        s = int(len(data) * 75 / 100)
        data = data[:s]
        label = label[:s]

    # split data into train and text data
    x_train, x_test, y_train, y_test = train_test_split(data, label, train_size=0.9)

    # Proposed method
    Proposed_PJSO_HDLTex.Proposed_HDLTEX.Classify(x_train, x_test, y_train, y_test, PRE, RECALL, F_M)

    return PRE, RECALL, F_M


