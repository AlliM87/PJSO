from keras.models import Sequential
import numpy as np
from keras.layers import Dense, Input, Flatten
from keras.layers import Conv1D, MaxPooling1D, Embedding, Dropout, GRU
from Proposed_PJSO_HDLTex import PJSO
from keras.optimizers import Adam as Opt


def Classify(x_train, x_test, y_train, y_test, PRE, RECALL, F_M):

    Pred = []

    # DNN
    nLayers = 3
    dropout = 0.5
    Number_Node = 100
    nClasses = len(np.unique(x_train))
    model = Sequential()
    model.add(Dense(Number_Node, input_dim=x_train.shape[0]))
    model.add(Dropout(dropout))

    for i in range(0, nLayers):
        model.add(Dense(Number_Node, activation='relu'))
        model.add(Dropout(dropout))
        model.add(Dense(nClasses, activation='softmax'))
        model.compile(loss='sparse_categorical_crossentropy',
                  optimizer=Opt(learning_rate=PJSO.Algm()),
                  metrics=['accuracy'])
        x_train1 = np.resize(x_train, (len(x_train), x_train.shape[0]))
        model.fit(x_train1, y_train, epochs=20, batch_size=32, verbose=0)
        x_test1 = np.resize(x_test, (len(x_test), x_train.shape[0]))

        pr1 = model.predict(x_test1)
        Pred.append(pr1)

    # RNN
    model = Sequential()
    model.add(GRU(128, input_shape=(x_train.shape[1], x_train.shape[1])))
    model.add(Dense(nClasses, activation='softmx'))
    model.compile(loss='sparse_categorical_crossentropy',
                  optimizer=Opt(learning_rate=PJSO.Algm()),
              metrics=['acc'])
    x_train2 = np.resize(x_train, (len(x_train), x_train.shape[1], x_train.shape[1]))
    model.fit(x_train2, y_train, epochs=20, batch_size=32, verbose=0)
    x_test1 = np.resize(x_test, (len(x_test), x_train.shape[1], x_train.shape[1]))

    pr2 = model.predict(x_test1)
    Pred.append(pr2)

    # CNN
    embedding_layer = Embedding(10 + 1,
                                10,
                                # weights=[embedding_matrix],
                                input_length=x_train.shape[1],
                                trainable=True)
    sequence_input = Input(shape=(len(x_train),))
    embedded_sequences = embedding_layer(sequence_input)
    a, b = 0.6, 0.8
    x = Conv1D(256, 5, activation='relu')(embedded_sequences)
    x = MaxPooling1D(5)(x)
    x = Conv1D(256, 5, activation='relu')(x)
    x = MaxPooling1D(5)(x)
    x = Conv1D(256, 5, activation='relu')(x)
    x = MaxPooling1D(35)(x)  # global max pooling
    x = Flatten()(x)

    model.compile(loss='sparse_categorical_crossentropy',
                  optimizer=Opt(learning_rate=PJSO.Algm()),
                  metrics=['acc'])
    model.fit(x_train, y_train, epochs=20, batch_size=32, verbose=0)
    # x_test = np.resize(x_test, (200, 50, 9204))
    pr3 = model.predict(x_test)
    Pred.append(pr3)
    target = np.array(y_test)

    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(target)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(Pred)):
            if target[i].any() == c and Pred[i].any() == c:
                tp += 1
            if target[i].any() != c and Pred[i].any() != c:
                tn += 1
            if target[i].any() == c and Pred[i].any() != c:
                fn += 1
            if target[i].any() != c and Pred[i].any() == c:
                fp += 1
    pre = tp / (tp + fp)
    recall = tp / (tp + fn)
    fm = 2 * tp / (2 * tp + fp + fn)
    PRE.append(pre)
    RECALL.append(recall)
    F_M.append(fm)

    return PRE, RECALL, F_M
