import random
import numpy as np
import Proposed_PJSO_HDLTex.PO_fitness


n, lam_max, t_max = 10, 1, 100
lb, ub = 0, 10                                                                              # lower, upper bound


# Initialize population
def initialize(nn, l, u):
    ran_data = []
    for i in range(nn):                                                                    # row to the size of nn
        tem = []
        for j in range(nn):                                                                # column to the size of nn
            tem.append(random.uniform(l, u))                                               # random values between bound
        ran_data.append(tem)
    return ran_data


# get the constituency winners
def get_constituency_winners(population, ind):
    column_elmts = []
    for i in zip(*population):                                                              # zip elements column-wise
        column_elmts.append(np.array(i).tolist())                                           # get column elements
    return column_elmts[ind]                                                                # return best index column


# updating position (eqn. 9)
def update_position_1(m, r, pt, pt_1):
    if pt_1 <= pt <= m or pt_1 >= pt >= m:
        up_pos = m+r*(m-pt)
    if pt_1 <= m <= pt or pt_1 >= m >= pt:
        # up_pos = m+(2*r-1)*(np.abs(m-pt))
        up_pos = (r*pt)-((3*r*m)*r)-(pt_1*(1-r))                                            # update
    if m <= pt_1 <= pt or m >= pt_1 >= pt:
        up_pos = m+(2*r-1)*(np.abs(m-pt_1))
    return up_pos


# eqn. (10)
def update_position_2(m, r, pt, pt_1):
    if pt_1 <= pt <= m or pt_1 >= pt >= m:
        up_pos = m+(2*r-1)*(np.abs(m-pt))
    if pt_1 <= m <= pt or pt_1 >= m >= pt:
        up_pos = pt_1+r*(pt-pt_1)
    if m <= pt_1 <= pt or m >= pt_1 >= pt:
        up_pos = m+(2*r-1)*(np.abs(m-pt_1))
    return up_pos


# Algm 2: Election Campaign
def ElectionCampaign(pos, prev_pos, lp, cl, f, pr_f):
    Position = []
    for i in range(len(pos)):
        tem = []
        if f[i] <= pr_f[i]:
            for k in range(len(pos[i])):
                m_ = lp[k]                                                                 # leader
                r = random.random()                                                        # ran[0,1]
                pos[i][k] = update_position_1(m_, r, pos[i][k], prev_pos[i][k])            # update position by eqn. (9)

                m_ = cl[k]                                                                 # winner
                r = random.random()                                                        # ran[0,1]
                pik = update_position_1(m_, r, pos[i][k], prev_pos[i][k])                  # update position by eqn. (9)
                tem.append(pik)
        else:
            for k in range(len(pos[i])):
                m_ = lp[k]                                                                # leader
                r = random.random()                                                       # ran[0,1]
                pos[i][k] = update_position_2(m_, r, pos[i][k], prev_pos[i][k])           # update position by eqn. (10)

                m_ = cl[k]                                                                # winner
                r = random.random()                                                       # ran[0,1]
                pik = update_position_2(m_, r, pos[i][k], prev_pos[i][k])                 # update position by eqn. (10)
                tem.append(pik)
        Position.append(tem)
    return Position


# Party switching phase
def PartySwitching(P, lam, f):
    for i in range(len(P)):
        for j in range(len(P[i])):
            sp = random.random()                                                           # ran[0,1]
            if sp < lam:
                r = random.randint(1, n)                                                   # ran[1, n]
                q = np.argmax(f)
                Prq, Pij = P[r-1][q].copy(), P[i][j].copy()
                P[r-1][q], P[i][j] = Pij, Prq                                              # swap


def ParliamentaryAffairs(C_, P, i, ft):
    C_new = []
    for j in range(len(P)):
        r = random.randint(1, n)
        a = random.random()                                                                # ran[0,1]
        C_new.append(C_[r-1]+(2*a-1)*(np.abs(C_[r-1]-C_[j])))
    C = []
    C.append(C_)
    C.append(C_new)
    fit_C = Proposed_PJSO_HDLTex.PO_fitness.func(C)
    if fit_C[1] <= fit_C[0]:
        for j in range(len(P)):
            C_[j] = C_new[j]
            P[i][j] = C_new[j]
        ft[i] = fit_C[1]


def Algm():
    P = initialize(n, lb, ub)                                   # initial population
    fit = Proposed_PJSO_HDLTex.PO_fitness.func(P)                        # fitness
    bst_index = np.argmin(fit)                                  # best fitness index
    P_ = P[bst_index]                                           # Party leader, P* (eqn. 6) -- row_wise best
    C_ = get_constituency_winners(P, bst_index)                 # constituency winners, C* (eqn. 12) -- column_wise best
    overall_best, overall_fit = [], []

    # initial
    prev_position = P.copy()                                                                # previous position
    prev_fit = fit.copy()                                                                   # previous fitness
    lam = lam_max                                                                           # lamda value

    t = 0
    while (t<t_max):                                                                        # loop begins
        P_temp = P.copy()                                                                   # temporary position
        fit_temp = fit.copy()                                                               # temporary fitness
        P = ElectionCampaign(P, prev_position, P_, C_, fit, prev_fit)                       # Election campaign
        PartySwitching(P, lam, fit)                                                         # Party switching phase

        # Election phase
        fit = Proposed_PJSO_HDLTex.PO_fitness.func(P)                # fitness
        bst_index = np.argmin(fit)                          # best fitness index
        P_ = P[bst_index]                                   # Party leader, P* (eqn. 6) -- row_wise best
        C_ = get_constituency_winners(P, bst_index)         # constituency winners, C* (eqn. 12) -- column_wise best
        overall_fit.append(min(fit))
        overall_best.append(P_)

        ParliamentaryAffairs(C_, P, bst_index, fit)         # Parliamentary affairs
        prev_position = P_temp.copy()
        prev_fit = fit_temp
        lam = lam - (lam_max/t_max)

        t += 1
    bst = np.argmin(overall_fit)
    return bst
