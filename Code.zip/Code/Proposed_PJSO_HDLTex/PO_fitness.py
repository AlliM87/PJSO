import random


def func(soln):
    fit = []
    for i in range(len(soln)):
        fit.append(random.random())  # random fit
    return fit
