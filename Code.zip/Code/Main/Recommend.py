import numpy as np


def recommendation(Matched_learner, Relevant_learners, VBM, reviews):

    # get matched binary sequence of learner
    matched_binary_seq = []
    for i in range(len(Matched_learner)):
        matched_learner_index = Relevant_learners[Matched_learner[i]]
        matched_binary_seq.append(VBM[matched_learner_index])   # matched learner binary sequence

    score = []
    for i in range(len(matched_binary_seq)):
        review_data = 0
        for j in range(len(matched_binary_seq[i])):
            if matched_binary_seq[i][j] == 1:
                review_data += int(reviews[j][4])   # positive store of the review
        score.append(review_data)
    r = np.argmax(score)

    return matched_binary_seq[r]    # return matched seq. with more positive reviews
