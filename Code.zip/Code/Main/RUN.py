from Main import read, read_feature, BFC
import csv, numpy as np
import warnings
warnings.filterwarnings("ignore", category=np.VisibleDeprecationWarning)
from Main import group_matching, Relevant_learner, Matching_learner, Recommend
import Proposed_PJSO_HDLTex.RUN


def read_data(dataset):
    datas = []
    with open(dataset, 'rt')as f:
        content = csv.reader(f)                     # read csv content
        for rows in content:                        # row of data
            tem = []
            for cols in rows:                       # attributes in each row
                tem.append(int(cols))               # add value to tem array
            datas.append(tem)                       # add 1 row of array value to dataset
    return datas


def preprocessing_data(E, L_ID, I_ID, d_s):

    if d_s == "50 (%)": F = "_50"
    elif d_s == "75 (%)": F = "_75"
    else: F = "_100"

    # Learner Matrix & binary matrix
    L_matrix, L_binary_matrix = [], []              # L_matrix size = n_learner * ordered courses of that learner
    for i in range(len(L_ID)):                      # to the size of n_learner
        tem_m, tem_bm = [], []

        for j in range(len(E)):                     # check to the size of n_events for each learner
            if E[j][0] == L_ID[i]:
                tem_m.append(int(E[j][1]))          # add the courses ordered by each learner from events

        for j in range(len(I_ID)):                  # to the size of course
            if int(I_ID[j]) in tem_m:               # if learner orders that course, binary 1
                tem_bm.append(1)
            else:
                tem_bm.append(0)                    # else 0

        L_matrix.append(tem_m)
        L_binary_matrix.append(tem_bm)
    np.savetxt("Learner Matrix" + F + ".txt", L_matrix, delimiter=',', fmt='%s')                # write data to txt file
    np.savetxt("Learner_Binary_Matrix" + F + ".csv", L_binary_matrix, delimiter=',', fmt='%s')  # write data to csv file

    # course Matrix & binary matrix
    I_matrix, I_binary_matrix = [], []              # I_matrix size = n_course * n_learners ordered that course
    for i in range(len(I_ID)):                      # to the size of n_course
        tem_m, tem_bm = [], []

        for j in range(len(E)):                     # check to the size of n_events for each course
            if E[j][1] == I_ID[i]:
                tem_m.append(int(E[j][0]))          # add the visitors who ordered that course from events

        for j in range(len(L_ID)):                  # to the size of visitor
            if int(L_ID[j]) in tem_m:               # if course is ordered by that visitor, binary 1
                tem_bm.append(1)
            else:
                tem_bm.append(0)                    # else 0

        I_matrix.append(tem_m)
        I_binary_matrix.append(tem_bm)
    np.savetxt("course Matrix" + F + ".txt", I_matrix, delimiter=',', fmt='%s')                 # write data to txt file
    np.savetxt("course_Binary_Matrix" + F + ".csv", I_binary_matrix, delimiter=',', fmt='%s')   # write data to csv file


# course & learner binary matrix
def generate_binary_matrix(E, L_ID, I_ID, data_s):
    print("\nCollective matrix computation in process..")
    preprocessing_data(E, L_ID, I_ID, data_s)


def callmain(data_s, n_cluster, q):

    learner_ID, course_ID, events = read.data("Ekhool.csv", data_s)

    generate_binary_matrix(events, learner_ID, course_ID, data_s)

    if data_s == "50":F = "_50"
    elif data_s == "75":F = "_75"
    else:F = "_100"
    L_binary_matrix = read_data("Learner_Binary_Matrix" + F + ".csv")   # size = n_learner * n_courses
    course_Learner_BM = read_data("course_Binary_Matrix" + F + ".csv")  # size = n_courses * n_learner

    q = int(q)
    n_cluster = int(n_cluster)
    Qry = read_data("Query" + F + ".csv")                               # read the query
    query = Qry[q-1]                                                    # query in q-1 index (since array starts from 0)

    data, clas = [], []                                                 # array initialization
    feature_data, feature_label = read_feature.extract(data, clas, 'Ekhool.csv', data_s)

    cluster = BFC.cluster(course_Learner_BM, n_cluster)

    Best_cluster_group = group_matching.matching(n_cluster, cluster, query)

    Learner_Binary_sequence, Relevant_learners = Relevant_learner.callmain(Best_cluster_group, L_binary_matrix)

    Matched_learner = Matching_learner.callmain(query, Learner_Binary_sequence)

    Recommended = Recommend.recommendation(Matched_learner, Relevant_learners, L_binary_matrix, feature_data)
    Recommended = np.array(Recommended)

    np.savetxt("recommend.csv", Recommended, delimiter=',', fmt="%s", encoding='utf-8')

    PRE, RECALL, F_M = [], [], []
    PRE, RECALL, F_M = Proposed_PJSO_HDLTex.RUN.Main(PRE, RECALL, F_M, data_s)

    return PRE, RECALL, F_M


if __name__ == '__main__':
    # Select Dataset size
    Data_size = input("Enter Dataset size:")         # (50(%), 75(%), 100(%))

    Cluster_size = input("Enter Cluster size:")         # (3, 4, 5)

    Query = input("Enter Query size:")         # (1, 2, 3, 4, 5)

    # Main function
    callmain(Data_size, Cluster_size, Query)













