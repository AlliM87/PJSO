from scipy.spatial import distance
import random
import numpy as np
import math


def dist_chord(query, Groups):
        a, b, c = 0, 0, 0
        for i in range(len(query)):
            a += query[i] * Groups[i]
            b += query[i] ** 2
            c += Groups[i] ** 2
        d = math.sqrt(2 - 2 * (a / (math.sqrt(b * c))))
        return d


def matching(n_cluster, clustered, query):
    Groups = []
    for i in range(n_cluster):
        tem = []
        for j in range(len(clustered)):
            if clustered[j] == (i+1):
                tem.append(1)
            else:
                tem.append(0)
        Groups.append(tem)

    dist, dist1 = [], []
    for i in range(len(Groups)):
        dist.append(distance.minkowski(query, Groups[i]))
    for i in range(len(Groups)):
        dist1.append(distance.chebyshev(query, Groups[i]))

    a = random.uniform(0, 1)
    best = (a * np.argmin(dist)) + ((1 - a) * np.argmin(dist1))
    best = int(best)
    return Groups[best]
