import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
import re
from textblob import TextBlob
import pandas as pd


def Extract(Datas):
# All_Caps
    def find_cap(sentence):
        count = 0
        for a in str(sentence):              # Checking for uppercase letter.
            if (a.isupper()) == True:
                count += 1              # uppercase count
        return count

# Numerical Words
    def num_words(sentence):
        nums = '0 1 2 3 4 5 6 7 8 9'
        num_count = 0
        for char in str(sentence):
            if char in nums:
                num_count += 1
        return num_count

# TF_IDF
    def TF_IDF(sentence):
        DD = []
        for ii in range(len(sentence)):
            sentence = np.array(sentence)
            c = str(sentence[ii])[1:-1]
            vectorizer = TfidfVectorizer()
            X = vectorizer.fit_transform([str(c)])
            x = X.toarray()
            x = np.mean(x, axis=1)
            DD.append(x)
        return DD

# Elongated Words
    def get_elongated_words(sentence):
        sentence = str(sentence)
        elong = re.sub("([a-zA-Z])\\1{2,}", "", str(sentence))
        count = 0
        for i in range(len((sentence))):
            a = bool(elong.find(sentence[i]))               # boolean true if word is elongated
            if a is True:
                count += 1
        return count

# Punctuation
    def get_punctuation(sentence):
        punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
        punct_count = 0
        for char in str(sentence):
            if char in punctuations:
                punct_count += 1
        return punct_count

# Emoticons
    def emoticons(text):
        text = str(text)
        emot1 = []
        emot2 = []
        for feedback in text:
            feedback_polarity = TextBlob(feedback).sentiment.polarity
            if feedback_polarity > 0:
                emot1.append(feedback)
                continue
            emot2.append(feedback)

        Emotions = len(emot1) + len(emot2)
        eyes, noses, mouths = r":;8BX=", r"-~'^", r")(/\|DP"
        pattern1 = "[%s][%s]?[%s]" % tuple(map(re.escape, [eyes, noses, mouths]))

        smileys = """:-) :) :o) :] :3 :c) :> =] 8) =) :} :^) 
                     :D 8-D 8D x-D xD X-D XD =-D =D =-3 =3 B^D""".split()
        pattern2 = "|".join(map(re.escape, smileys))

        if len(re.findall(pattern1, text)) > 0:
            count = len(re.findall(pattern1, text))
        elif len(re.findall(pattern2, text)) > 0:
            count = len(re.findall(pattern2, text))
        elif Emotions > 0:
            count = Emotions
        return count

# Sentence Length
    def get_length_text(text):
        words = 0
        for i in range(len(str(text))):
            words += 1
        return words

# Hashtags
    def Get_Hashtag(text):
        hash = []
        text = str(text)
        for ii in range(len(text)):
            H = re.findall(r"#(\w+)", text[ii])
            if len(H) > 0:
                hash.append(H)
            count = len(hash)
        return count

    TF_IDF_ = np.array(TF_IDF(Datas)).flatten()

    Elong, Punct, Emo, Bag_words, len_text, Hash, Caps, Num_words = [], [], [], [], [], [], [], []
    for i in range(len(Datas)):
        Num_words.append(num_words(Datas[i]))
        Caps.append(find_cap(Datas[i]))
        Elong.append(get_elongated_words(Datas[i]))
        len_text.append(get_length_text(Datas[i]))
        Emo.append(emoticons(Datas[i]))
        Hash.append(Get_Hashtag(Datas[i]))
        Punct.append(get_punctuation(Datas[i]))

    Feature = [Num_words, Caps, Elong, len_text, Emo, Hash, Punct, TF_IDF_]
    Feature = np.transpose(Feature)
    np.savetxt("Feature.csv", Feature, delimiter=',', fmt="%s")


Datas = pd.read_csv("...\Bert.csv", header=None, error_bad_lines=False)
Datas = np.array(Datas)
Feature = Extract(Datas)




