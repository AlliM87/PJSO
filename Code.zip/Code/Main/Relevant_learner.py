

def get_index_rel_learner(cluster_gp, learner_bm):
    rel_li_index = []

    # index of items ordered in user query
    query_item_index = []
    for i in range(len(cluster_gp)):                                        # check input user query
        if cluster_gp[i] == 1:
            query_item_index.append(i)                  # if 1, item ordered by input user

    # get the visitors who added the items, that are ordered by input user
    for i in range(len(learner_bm)):                                        # check each visitor
        for j in range(len(query_item_index)):                              # for the item ordered
            if learner_bm[i][query_item_index[j]] == 1:                   # same item ordered by visitor
                if i not in rel_li_index:
                    rel_li_index.append(i)           # add unique visitor index
    return rel_li_index


def get_learner_b_seq(Relevant_learners, learner_bm):
    b_seq = []
    for i in range(len(Relevant_learners)):
        b_seq.append(learner_bm[Relevant_learners[i]]) # binary sequence of relevant learner(items ordered by rel.learner)
    return b_seq


def callmain(best_gp, learner_bm):
    Relevant_learners = get_index_rel_learner(best_gp, learner_bm)
    binary_seq = get_learner_b_seq(Relevant_learners, learner_bm)
    return binary_seq, Relevant_learners