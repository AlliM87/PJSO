from scipy.spatial import distance
import numpy
import random


def callmain(query, Learner_Binary_sequence):
    dist = []
    for i in range(len(Learner_Binary_sequence)):
        dist.append(distance.minkowski(query, Learner_Binary_sequence[i]))
    dist1 = []
    for i in range(len(Learner_Binary_sequence)):
        dist1.append(distance.chebyshev(query, Learner_Binary_sequence[i]))

    a = random.uniform(0, 1)
    best = (a * numpy.argmin(dist)) + ((1 - a) * numpy.argmin(dist1))
    best = int(best)
    return Learner_Binary_sequence[best]

