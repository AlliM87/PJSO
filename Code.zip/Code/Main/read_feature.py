import re, csv, numpy as np
from textblob import TextBlob


def preprocess_func(input_data, clas, dataset, d_s):

    feature, cap, emo, tag, elong, pos_score, neg_score, punc = [], [], [], [], [], [], [], []

    # All - caps
    def find_cap(sentence):
        count = 0
        for a in sentence:                              # Checking for uppercase letter.
            if (a.isupper()) == True:
                count += 1                              # uppercase count
        return count

    # Elongated words
    def get_elongated_words(sentence):
        elong = re.compile("([a-zA-Z])\\1{2,}")
        count = 0
        for i in range(len(sentence)):
            a = bool(elong.search(sentence[i]))         # boolean true if word is elongated
            if a is True:
                count += 1
        return count

    # positive & negative score
    def get_senti_score(sentence):
        pos, neg = 0, 0
        for i in range(len(sentence)):
            sentiment = ""
            language = 'en'
            sentiment = TextBlob(sentence[i])           # processing text
            Senti_core = sentiment.sentiment.polarity   # score calculation
            if Senti_core > 0:                          # positive score
                pos += 1
            else:                                       # negative score
                neg += 1
        return pos, neg

    # Punctuation
    def get_punctuation(sentence):
        punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
        punct_count = 0
        for char in sentence:
            if char in punctuations:
                punct_count += 1
        return punct_count

    # read the tweet data
    def read_csv(data, r, u):
        with open(data, 'r', encoding='UTF-8', newline='')as f:     # read data with special characters
            data = csv.reader(f)

            # Store data in array
            for row in data:
                clas.append(row[r])                                 # class attribute from each row (r)
                review = row[u]                                     # review data of each row
                input_data.append(review)
                cap.append(find_cap(review))
                emo.append(len(re.findall(':\)|;\)|:-\)|\(-:|:-D|=D|:P|xD|X-p|\^\^|:-*|\^\.\^|\^\-\^|\^\_\^|\,-\)|\)-:|:\'\(|:\(|:-\(|:\S|T\.T|\.\_\.|:<|:-\S|:-<|\*\-\*|:O|=O|=\-O|O\.o|XO|O\_O|:-\@|=/|:/|X\-\(|>\.<|>=\(|D:',row[u])))
                tag.append(len(re.findall(r"#(\w+)", review)))
                elong.append(get_elongated_words(review.split()))     # split the review by space in array
                positive, negative = get_senti_score(review.split())
                pos_score.append(positive)
                neg_score.append(negative)
                punc.append(get_punctuation(review))

    # generating feature by adding all feature to an array named feature
    def generate_feature():
        for i in range(0, len(cap)):
            feature.append([])
            feature[i].append(cap[i])
            feature[i].append(emo[i])
            feature[i].append(tag[i])
            feature[i].append(elong[i])
            feature[i].append(pos_score[i])
            feature[i].append(neg_score[i])
            feature[i].append(punc[i])

    # function to read the input
    read_csv(dataset, 2, 3)                                              # 3rd(ratings as target), 7th(review) column
    generate_feature()
    Feature, label = [], []
    for i in range(10000):
        Feature.append(feature[i+1])
        label.append(clas[i+1])

    if d_s == "50":
        s = int(len(Feature) * 50 / 100)
        F = "_50"
    elif d_s == "75":
        s = int(len(Feature) * 75 / 100)
        F = "_75"
    else: F = "_100"
    Feature = Feature[:s]
    label = label[:s]
    np.savetxt("feat" + F + ".csv", Feature, delimiter=',', fmt='%s')         # write data to csv file
    np.savetxt("class" + F + ".csv", label, delimiter=',', fmt='%s')             # write data to csv file


# reading preprocessed data
def read_preprocessed_data(file, n):
    datas = []
    if(n is 1):                         # 1D array
        with open(file, 'rt')as f:
            content = csv.reader(f)     # read csv content
            for rows in content:        # row of data
                for cols in rows:       # attributes in each row
                    datas.append(cols)  # add value to array
    else:                               # 2D array
        with open(file, 'rt')as f:
            content = csv.reader(f)     # read csv content
            for rows in content:        # row of data
                tem = []
                for cols in rows:       # attributes in each row
                    tem.append(cols)    # add value to array
                datas.append(tem)       # 2D array
    return datas


def extract(data, clas, dataset, d_s):
    # preprocess_func(data, clas, dataset, d_s)
    if d_s == "50":F = "_50"
    elif d_s == "75":F = "_75"
    else:F = "_100"
    Feature = read_preprocessed_data("feat" + F + ".csv", 2)
    label = read_preprocessed_data("class" + F + ".csv", 1)
    return Feature, label
