import csv, random, numpy as np


def read_preprocessed_data(file, n):
    datas = []
    if(n is 1):                         # 1D array
        with open(file, 'rt')as f:
            content = csv.reader(f)     # read csv content
            for rows in content:        # row of data
                for cols in rows:       # attributes in each row
                    datas.append(cols)  # add value to array
    else:                               # 2D array
        with open(file, 'rt')as f:
            content = csv.reader(f)     # read csv content
            for rows in content:        # row of data
                tem = []
                for cols in rows:       # attributes in each row
                    tem.append(cols)    # add value to array
                datas.append(tem)       # 2D array
    return datas


# reading data
def read_dataset(dataset):
    datas = []
    with open(dataset, 'r', encoding='UTF-8', newline='')as f:      # read data
        content = csv.reader(f)                                     # read csv content
        for rows in content:                                        # row of data
            tem = []
            for cols in rows:                                       # attributes in each row
                tem.append(cols)                                    # add value to tem array
            datas.append(tem)                                       # add 1 row of array value to dataset
    datas.remove(datas[0])
    data = []
    for i in range(10000):
        data.append(datas[i])                    # to avoid memory error
    return data


def generate_query(n_course):
    n_query, qry = 10, []                                           # generating 10 query sequence
    for i in range(n_query):
        tem = []
        for j in range(n_course):
            r = random.random()                                     # random values
            if r > 0.8:
                tem.append(1)                                       # if > 0.8, then 1(add to cart)
            else:
                tem.append(0)
        qry.append(tem)
    return qry


def preprocess(filename, data_s):

    input = read_dataset(filename)
    F = []
    if data_s == "50":
        s = int(len(input) * 50/100)
        input = input[:s]
        F.append("_50")

    elif data_s == "75":
        s = int(len(input) * 75/100)
        input = input[:s]
        F.append("_75")

    else:F.append("_100")

    print("Data: ", len(input))
    input_data = np.transpose(input)               # transpose the read data, to get 2nd & 4th column
    l_ID, it_ID, events, reviews = np.unique(input_data[1]), np.unique(input_data[0]), [], []
    l_ID, it_ID = l_ID.tolist(), it_ID.tolist()                     # convert array to list
    learner_ID, course_ID = [], []

    for i in range(len(input_data[1])):
        learner_ID.append(l_ID.index(input_data[1][i]))             # replace string by its unique index
        course_ID.append(it_ID.index(input_data[0][i]))

    for i in range(len(learner_ID)):
        tem = []
        tem.append(learner_ID[i])
        tem.append(course_ID[i])
        events.append(tem)                                          # append activities of learner to event

    query = generate_query(len(it_ID))
    print("\nLearner ID: ", len(l_ID))
    print("\nCourse ID: ", len(it_ID))
    # np.savetxt("Learner ID" + F[0] + ".txt", np.unique(learner_ID), delimiter=',', fmt='%s')  # write data to txt file
    # np.savetxt("course ID" + F[0] + ".txt", np.unique(course_ID), delimiter=',', fmt='%s')
    # np.savetxt("Events" + F[0] + ".txt", events, delimiter=',', fmt='%s')
    # np.savetxt("Query" + F[0] + ".csv", query, delimiter=',', fmt='%s')                       # write data to csv file


def data(filename, data_s):

    # preprocess(filename, data_s)
    if data_s == "50":F = "_50"
    elif data_s == "75":F = "_75"
    else:F = "_100"

    l_ID = read_preprocessed_data("Learner ID" + F + ".txt", 1)
    it_ID = read_preprocessed_data("course ID" + F + ".txt", 1)
    events = read_preprocessed_data("Events" + F + ".txt", 2)

    return l_ID, it_ID, events


