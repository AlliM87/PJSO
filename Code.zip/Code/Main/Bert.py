from transformers import BertTokenizer


print("Bert Tokenization.....")
file = open("course_review.txt", "r", encoding='utf-8')            # Read the Dataset
datas = file.readlines()
file.close()
data = []
D = []
for i in range(len(datas)):
    tz = BertTokenizer.from_pretrained("bert-base-cased")
    tz.convert_tokens_to_ids(["characteristically"])
    D.append(tz.tokenize(datas[i]))
    data.append(tz.tokenize(datas[i]))
    f = open('Bert.csv', 'w', encoding='utf-8')
    for item in D:
        f.write(','.join([(x) for x in item]) + '\n')
    f.close()

