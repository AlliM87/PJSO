import pandas as pd
import numpy as np


input = pd.read_csv("D:\Divya\Madhavi Bandhari_paper2\Code\Main\Ekhool.csv", header=None)
Recommended = pd.read_csv("D:\Divya\Madhavi Bandhari_paper2\Code\Main\\recommend.csv", header=None)

Recommended = np.array(Recommended).flatten()
ind1 = []
for index, val in enumerate(Recommended):
    if val == 0:
        print("....")
    else:
        ind = index
        ind1.append(ind)

course_review, course_label = [], []
for index, val in enumerate(input[0]):
    for j in ind1:
        j = str(j)
        if val == j:
            reviews = input.iloc[:, -1]
            reviews = np.array(reviews)

            label = input.iloc[:, 2]
            label = np.array(label)

            course_review.append(reviews[index])
            course_label.append(label[index])

            # np.savetxt("course_review.txt", course_review, delimiter=',', fmt="%s", encoding='utf-8')
            # np.savetxt("label.csv", course_label, delimiter=',', fmt="%s", encoding='utf-8')








